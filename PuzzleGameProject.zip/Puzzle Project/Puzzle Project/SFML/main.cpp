#include <SFML/Graphics.hpp>
#include<SFML/Audio.hpp>
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;
using namespace sf;

// Constants for the play area and pool area
const int PLAY_AREA_WIDTH = 112 * 8;
const int PLAY_AREA_HEIGHT = 81 * 8;
const int BOX_START_X = 17;
const int BOX_START_Y = 133;
const FloatRect POOL_AREA(935, 131, 548, 653);

void flashSolvedPuzzle(RenderWindow& window, const string& solutionPath) {
    Texture solvedTexture;
    if (!solvedTexture.loadFromFile(solutionPath)) {
        cout << "Error loading solution image: " << solutionPath << endl;
        return;
    }
    Sprite solvedSprite(solvedTexture);
    solvedSprite.setPosition(BOX_START_X, BOX_START_Y);

    window.clear();
    window.draw(solvedSprite);
    window.display();
    sleep(seconds(2)); // Flash for 2 seconds
}

void playPuzzleGame(RenderWindow& window, int level, int& score) {
    Clock timer;

    Texture background;
    if (!background.loadFromFile("background.jpg")) {
        cout << "Error loading background" << endl;
        return;
    }
    Sprite bg;
    bg.setTexture(background);

    while (level <= 3) {
        int gridRows = 8 + (level - 1); // 8x8 for level 1, 9x9 for level 2, 10x10 for level 3
        int gridCols = gridRows;
        int boxWidth = PLAY_AREA_WIDTH / gridCols;
        int boxHeight = PLAY_AREA_HEIGHT / gridRows;

        Sprite gridSprites[10][10];
        Texture gridTextures[10][10];
        FloatRect boxes[10][10];
        Sprite* selectedSprite = nullptr;

        srand(static_cast<unsigned>(time(nullptr)));

       


        // Load textures, initialize sprites, and define theoretical boxes
        for (int i = 0; i < gridRows; i++) {
            for (int j = 0; j < gridCols; j++) {
                string filename = "level" + to_string(level) + "/" + to_string(i) + "_" + to_string(j) + ".jpeg";

                if (!gridTextures[i][j].loadFromFile(filename)) {
                    cout << "Error loading texture: " << filename << endl;
                    return;
                }

                gridSprites[i][j].setTexture(gridTextures[i][j]);
                gridSprites[i][j].setScale(
                    static_cast<float>(boxWidth) / gridTextures[i][j].getSize().x,
                    static_cast<float>(boxHeight) / gridTextures[i][j].getSize().y
                );

                // Place sprites randomly but within POOL_AREA
                int randomX = POOL_AREA.left + rand() % static_cast<int>(POOL_AREA.width - boxWidth);
                int randomY = POOL_AREA.top + rand() % static_cast<int>(POOL_AREA.height - boxHeight);
                gridSprites[i][j].setPosition(randomX, randomY);

                // Define grid boxes
                boxes[i][j] = FloatRect(
                    BOX_START_X + j * boxWidth,
                    BOX_START_Y + i * boxHeight,
                    boxWidth,
                    boxHeight
                );
            }
        }

        // Function to check if all sprites are in order
        auto checkWinCondition = [&]() -> bool {
            for (int i = 0; i < gridRows; i++) {
                for (int j = 0; j < gridCols; j++) {
                    Vector2f correctPosition(boxes[i][j].left, boxes[i][j].top);
                    if (gridSprites[i][j].getPosition() != correctPosition) {
                        return false;
                    }
                }
            }
            return true;
            };

        // Main level loop
        bool levelCompleted = false;
        while (window.isOpen() && !levelCompleted) {
            Event event;
            while (window.pollEvent(event)) {
                if (event.type == Event::Closed) {
                    window.close();
                    return;
                }

                // Flash button
                if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left) {
                    Vector2i mousePos = Mouse::getPosition(window);
                    if (mousePos.x > 10 && mousePos.x < 110 && mousePos.y > 10 && mousePos.y < 50) {
                        string solutionPath = "level" + to_string(level) + "/solution.jpeg";
                        flashSolvedPuzzle(window, solutionPath);
                    }

                    for (int i = gridRows - 1; i >= 0; --i) {
                        for (int j = gridCols - 1; j >= 0; --j) {
                            if (gridSprites[i][j].getGlobalBounds().contains(mousePos.x, mousePos.y)) {
                                selectedSprite = &gridSprites[i][j];
                                break;
                            }
                        }
                        if (selectedSprite) break;
                    }
                }

                // Detect mouse release
                if (event.type == Event::MouseButtonReleased && event.mouseButton.button == Mouse::Left) {
                    if (selectedSprite) {
                        Vector2f spritePos = selectedSprite->getPosition();

                        int bestRow = -1, bestCol = -1;
                        float maxArea = 0.0f;

                        for (int i = 0; i < gridRows; i++) {
                            for (int j = 0; j < gridCols; j++) {
                                FloatRect spriteBounds = selectedSprite->getGlobalBounds();
                                FloatRect intersection;

                                if (spriteBounds.intersects(boxes[i][j], intersection)) {
                                    float area = intersection.width * intersection.height;
                                    if (area > maxArea) {
                                        maxArea = area;
                                        bestRow = i;
                                        bestCol = j;
                                    }
                                }
                            }
                        }

                        if (bestRow != -1 && bestCol != -1) {
                            Vector2f correctPosition(boxes[bestRow][bestCol].left, boxes[bestRow][bestCol].top);

                            if (selectedSprite->getPosition() != correctPosition) {
                                selectedSprite->setPosition(correctPosition);
                                score += 10;
                            }
                        }

                        selectedSprite = nullptr;
                    }
                }
            }

            if (selectedSprite && Mouse::isButtonPressed(Mouse::Left)) {
                Vector2i mousePos = Mouse::getPosition(window);
                selectedSprite->setPosition(static_cast<float>(mousePos.x), static_cast<float>(mousePos.y));
            }

            if (checkWinCondition()) {
                levelCompleted = true;
                cout << "Level " << level << " completed!" << endl;
            }

            window.clear();
            window.draw(bg);

            // Draw Flash button
            RectangleShape flashButton(Vector2f(100, 40));
            flashButton.setPosition(10, 10);
            flashButton.setFillColor(Color::Red);
            window.draw(flashButton);

            Font font;
            if (font.loadFromFile("arial.ttf")) {
                Text flashText("Flash", font, 20);
                flashText.setPosition(20, 15);
                flashText.setFillColor(Color::White);
                window.draw(flashText);
            }

            for (int i = 0; i < gridRows; i++) {
                for (int j = 0; j < gridCols; j++) {
                    window.draw(gridSprites[i][j]);
                }
            }
            // Update and draw the timer
            
            if (font.loadFromFile("arial.ttf")) {
                int elapsedTime = static_cast<int>(timer.getElapsedTime().asSeconds());
                Text timerText("Time: " + to_string(elapsedTime) + "s", font, 20);
                timerText.setPosition(10, 60);
                timerText.setFillColor(Color::White);
                window.draw(timerText);
            }

            window.display();
        }

        level++;
    }

    cout << "Congratulations! You completed all levels!" << endl;
}
void showWelcomeScreen(RenderWindow& window) {
    Texture welcomeTexture;
    if (!welcomeTexture.loadFromFile("welcome.jpg")) {
        cout << "Error loading welcome screen!" << endl;
        return;
    }
    Sprite welcomeSprite(welcomeTexture);

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
                return;
            }
            if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left) {
                return; // Transition to levels screen
            }
        }

        window.clear();
        window.draw(welcomeSprite);
        window.display();
    }
}

int showLevelsScreen(RenderWindow& window) {
    // Replace these with your defined click areas for each level
    FloatRect levelClickRects[3] = {
        FloatRect(137, 52, 491, 245), // Level 1 area
        FloatRect(137,324,866,245), // Level 2 area
        FloatRect(137,600,1210,245)  // Level 3 area
    };

    Texture levelsTexture;
    if (!levelsTexture.loadFromFile("levels.jpg")) {
        cout << "Error loading levels screen!" << endl;
        return 1;
    }
    Sprite levelsSprite(levelsTexture);

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
                return 1;
            }
            if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left) {
                Vector2i mousePos = Mouse::getPosition(window);
                for (int i = 0; i < 3; ++i) {
                    if (levelClickRects[i].contains(mousePos.x, mousePos.y)) {
                        return i + 1; // Return selected level
                    }
                }
            }
        }

        window.clear();
        window.draw(levelsSprite);
        window.display();
    }

    return 1;
}

int main() {
    RenderWindow window(VideoMode(1600, 900), "SFML Puzzle Game");
    Music music; // Declare music object

    if (!music.openFromFile("music.mp3")) { // Make sure the path is correct
        cout << "Error loading music!" <<endl;
        return -1;
    }

    music.setLoop(true); // Set to loop the music
    music.play();
    showWelcomeScreen(window);

    int score = 0;
    while (true) {
        int level = showLevelsScreen(window);
        playPuzzleGame(window, level, score);
    }

    return 0;
}
